/**
 * Created by kaso on 11/6/2014.
 */

var app = angular.module('SupergeeksWidget',
    [
        'ui.router',
        'ui.bootstrap',
        'ngCookies',
        'ngAnimate',
        'SupergeeksWidget.Controllers',
        'SupergeeksWidget.Services',
        'SupergeeksWidget.directives'
    ]);

app.run(function ($rootScope, CurrentGadget,GadgetsInfoServ) {
    GadgetsInfoServ.get();
    $rootScope.currentGadget = CurrentGadget.fetch();
});

app.constant('ViewBaseURL','/Assets/app/views');

app.config(function ($stateProvider, $urlRouterProvider,ViewBaseURL) {
    //
    // For any unmatched url, redirect to /state1
    $urlRouterProvider.otherwise("/device-make");
    //
    // Now set up the states

    var deviceMake = {
        name: 'device-make',
        url: "/device-make",
        templateUrl: ViewBaseURL+"/device-make.html",
        controller: "DeviceMakeController",
        resolve: {
            'Makes': function (GadgetsInfoServ) {
                return GadgetsInfoServ.get();
            }
        }
    };

    var deviceModel = {
        name: 'device-model',
        url: "/device-model/:device_make",
        templateUrl: ViewBaseURL+"/device-model.html",
        controller: 'DeviceModelController',
        resolve: {
            'Models': function($stateParams,GadgetsInfoServ){
                var p = $stateParams.device_make;
                console.log(p);
                return GadgetsInfoServ.getModelsFor(p);
            },
            'CurrentMake': function($stateParams,GadgetsInfoServ){
                return GadgetsInfoServ.getMakeByName($stateParams.device_make);
            }
        }
    };

    var deviceColor = {
        name: 'device-color',
        url: "/device-color",
        templateUrl: ViewBaseURL+"/device-color.html",
        controller: 'DeviceColorController',
        resolve: {
            'validDevice': function ($rootScope, $state) {
                if ($rootScope.currentGadget.make == '' ||
                    $rootScope.currentGadget.model == '') {
                    $state.go('device-make');
                } else {
                    return true;
                }
            }
        }
    };

    var deviceSize = {
        name: 'device-size',
        url: "/device-size",
        templateUrl: ViewBaseURL+"/device-size.html",
        controller: 'DeviceSizeController',
        resolve: {
            'validDevice': function ($rootScope, $state) {
                if ($rootScope.currentGadget.make == '' ||
                    $rootScope.currentGadget.model == '' ||
                    $rootScope.currentGadget.color == ''
                ) {
                    $state.go('device-make');
                } else {
                    return true;
                }
            }
        }
    };

    var deviceNetwork = {
        name: 'device-network',
        url: "/device-network",
        templateUrl: ViewBaseURL+"/device-network.html",
        controller: 'DeviceNetworkController',
        resolve: {
            'Networks': function () {
                return [
                    {
                        name: 'Airtel',
                        image_url: 'airtel.jpg'
                    },
                    {
                        name: 'Mtn',
                        image_url: 'mtn.jpg'
                    },
                    {
                        name: 'Glo',
                        image_url: 'glo.jpg'
                    },
                    {
                        name: 'Etisalat',
                        image_url: 'etisalat.jpg'
                    }
                ]
            }
        }
    };

    var deviceCondition = {
        name: 'device-condition',
        url: "/device-condition",
        templateUrl: ViewBaseURL+"/device-condition.html",
        controller: 'DeviceConditionController',
        resolve: {
            'validDevice': function ($rootScope, $state) {
                if (
                    $rootScope.currentGadget.make == '' ||
                    $rootScope.currentGadget.model == '' ||
                    $rootScope.currentGadget.color == '' ||
                    $rootScope.currentGadget.size == ''
                ) {
                    $state.go('device-make');
                } else {
                    return true;
                }
            }
        }
    };

    var deviceReward = {
        name: 'device-reward',
        url: "/device-reward",
        templateUrl: ViewBaseURL+"/device-reward.html",
        controller: 'DeviceRewardController',
        resolve: {
            'validDevice': function ($rootScope, $state) {
                if ($rootScope.currentGadget.make == '' ||
                    $rootScope.currentGadget.model == '' ||
                    $rootScope.currentGadget.color == '' ||
                    $rootScope.currentGadget.size == '' ||
                    $rootScope.currentGadget.condition == ''
                ) {
                    $state.go('device-make');
                } else {
                    return true;
                }
            }
        }
    };

    var bookAppointment = {
        name: 'book-appointment',
        url: "/book-appointment",
        templateUrl: ViewBaseURL+"/book-appointment.html",
        controller: 'BookAppointmentController'
    };

    var success = {
        name: 'success',
        url: "/successful-booking",
        templateUrl: "app/views/book-success.html",
        controller: function ($scope) {

        }
    };

    $stateProvider
        .state(deviceMake)
        .state(deviceModel)
        .state(deviceColor)
        .state(deviceSize)
        .state(deviceNetwork)
        .state(deviceCondition)
        .state(deviceReward)
        .state(bookAppointment)
        .state(success)
});