<?php
/**
 * Created by PhpStorm.
 * User: kaso
 * Date: 12/20/2014
 * Time: 12:29 PM
 */

use ActiveRecord\Model;

class Network extends Model{

    static $belongs_to = array(
        array('gadget'),
    );

    public $name;

    function __construct($name)
    {
        $this->name = $name;
    }

    public static function Mtn(){
        return new Network('Mtn');
    }

    public static function Airtel(){
        return new Network('Airtel');
    }

    public static function Etisalat(){
        return new Network('Etisalat');
    }

    public static function Glo(){
        return new Network('Glo');
    }
}