<?php

use ActiveRecord\Model;

class Network extends Model{

}