<!DOCTYPE html>
<html class="no-js" ng-app="AdminApp">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,600,300,700' rel='stylesheet' type='text/css'>
</head>
<body>


<div class="navbar navbar-plain">
    <div class="container-fluid">
        <div class="navbar-header">
        </div>

        <ul class="nav navbar-nav">
        </ul>
    </div>
</div>

<div class="container">
    <div class="col-md-3">
        <div class="list-group">
                <a ui-sref="allDevices" class="list-group-item">All Devices</a>
                <ul class="list-group">
                    <li class="list-group-item"><a href="/devices">All</a></li>
                    <?php if(isset($models) && is_array($models)){
                        foreach($models as $value){
                            ?> <li class="list-group-item"><a href="?model=<?= $value->id ?>"><?= $value->name ?></a></li>
                        <?php
                        }
                    } ?>
                </ul>
            <a class="list-group-item" ui-sref="addMaker">Add Make</a>
            <a class="list-group-item" ui-sref="addDevice">Add Device</a>
        </div>
    </div>

    <div class="col-md-9">
        <div  class="row" ui-view>
        </div>
    </div>
</div>
</body>

<script id="AllDevices.html" type="text/ng-template">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h2>Devices</h2>
        </div>
        <table class="table table-striped">
            <thead>
                <tr>
                    <td>Make</td>
                    <td>Model</td>
                    <td>Sizes</td>
                    <td>Colors</td>
                    <td>Baseline Price</td>
                    <td>Conditions</td>
                </tr>
            </thead>
            <tbody>
            <?php if(isset($devices)){
                foreach($devices as $value){
                    ?>
                    <tr>
                        <td><?= GadgetMaker::find($value->gadget_maker_id)->name ?></td>
                        <td><?= $value->model ?></td>
                        <td>
                            <ul class="list-unstyled">
                                <?php
                                    foreach($value->sizes as $s){
                                        ?>
                                        <li> <?= $s->value ?></li>
                                    <?php
                                    }
                                ?>
                            </ul>
                        </td>
                        <td>
                            <ul class="list-unstyled">
                                <?php
                                    foreach($value->colors as $s){
                                        ?>
                                        <li> <?= $s->value ?></li>
                                    <?php
                                    }
                                ?>
                            </ul>
                        </td>
                        <td>
                            <ul class="list-unstyled">
                                <?php
                                    foreach($value->base_line_prices as $s){
                                        ?>
                                        <li><?= $s->size ?>: N<?= $s->value ?></li>
                                    <?php
                                    }
                                ?>
                            </ul>
                        </td>
                        <td>
                            <ul class="list-unstyled">
                                <li>Normal - 100%</li>
                                <li>Faulty - 60%</li>
                                <li>Bad - 0%</li>
                            </ul>
                        </td>
                        <td>
                            <a ng-click="deleteItem(<?=$value->id ?>)" class="btn btn-xs btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php
                }
            } ?>
            </tbody>
        </table>
    </div>
</script>
<script id="AddMaker.html" type="text/ng-template">
<div>
    <form action="devices/add-maker" method="post">
        <div class="col-md-6">
            <div  class="form-group">
                <input type="text" name="name" placeholder="Make"  class="form-control"/>
            </div>
            <div class="form-group">
                <label for="scratched-condition">Scratched Condition Value:</label>
                <input type="text" id="scratched-condition" name="scratched-condition" placeholder="%" class="form-control">
            </div>
            <div class="form-group">
                <label for="bad-condition">Bad Condition Value:</label>
                <input type="text" id="bad-condition" name="bad-condition" placeholder="%" class="form-control">
            </div>
            <div  class="form-group">
                <input type="submit" value="Submit"  class="btn"/>
            </div>
        </div>
    </form>
</div>
</script>
<script id="AddDevice.html" type="text/ng-template">
    <div>
        <form action="devices/add-device" method="post">
            <div  class="form-group col-md-6">
                <select class="form-control" name="gadget_maker_id">
                    <?php if(isset($models) && is_array($models)){
                        foreach($models as $value){
                            ?> <option value="<?= $value->id ?>"><?= $value->name ?></option>
                    <?php
                        }
                    } ?>
                </select>
            </div>

            <div  class="form-group col-md-6">
                <input type="text" placeholder="Model" name="model" class="form-control"/>
            </div>

            <div  class="form-group col-md-6">
                <textarea name="sizes" placeholder="Sizes, seperate each with a comma" class="form-control"></textarea>
            </div>
            <div  class="form-group col-md-6">
                <textarea name="colors" placeholder="Colours, seperate each with a comma" class="form-control"></textarea>
            </div>

            <div  class="form-group col-md-6">
                <textarea name="baselines" placeholder="baseline price eg 16gb: 10000,32gb: 20000" class="form-control"></textarea>
            </div>
            <div  class="form-group col-md-12">
                <input type="submit" value="Submit" class="btn"/>
            </div>

        </form>
    </div>
</script>

<script src="/Assets/app/vendor/angular.min.js"></script>
<script src="/Assets/app/vendor/angular-animate.min.js"></script>
<script src="/Assets/app/vendor/angular-ui-router.min.js"></script>
<script>
    var app = angular.module('AdminApp',[
        'ui.router',
        'ngAnimate'
    ]);

    app.config(function ($stateProvider, $urlRouterProvider) {
        //
        // For any unmatched url, redirect to /state1
        $urlRouterProvider.otherwise("/");
        //
        // Now set up the states
        var allDevices = {
            name: 'allDevices',
            url: "/",
            templateUrl: "AllDevices.html",
            controller: function($scope,$http){
                $scope.deleteItem = function(id){
                    var current = window.location.href,
                    url = window.location.origin +
                          window.location.pathname +
                          '/delete-device/'+id;
                   $http.delete(url).then(function(response){
                       window.location.href = current;
                   },function(response){

                   });
                }
            }
        };

        var addMaker = {
            name: 'addMaker',
            url: "/add-maker",
            templateUrl: "AddMaker.html",
            controller: function($scope){

            }
        };

        var addDevice = {
            name: 'addDevice',
            url: "/add-device",
            templateUrl: "AddDevice.html",
            controller: function($scope){
            }
        };


        $stateProvider
            .state(allDevices)
            .state(addDevice)
            .state(addMaker);

    });
</script>
</html>
